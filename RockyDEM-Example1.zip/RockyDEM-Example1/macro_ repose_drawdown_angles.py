'''
Warning: Changes in this file may not be correctly interpreted later on in the macro engine.

Generated script file.

Name for generated for macro: Repose and Drawdown Angle (4.3)

Macro description: Repose and Drawdown Angle Calcualtion.

@author: Lucilla Almeida
> Modernized: ESSS - 2019
'''

from __future__ import absolute_import, division, print_function, unicode_literals
import numpy
import math
import time
from matplotlib import cm
import matplotlib.pyplot as plt
import os
from esss_qt10.qt_traits.process_events import ProcessEvents



# Rocky project data
project = api.GetProject()
study = project.GetStudy()
timeset = study.GetTimeSet()

asklist = [("Enable repose angle calculation?", False),
           ("Time for the repose angle calculation", [int(len(timeset)/2)] + ["%.2f" % ts.second for ts in timeset]),
           ("Enable drawdown angle calculation?", False),
           ("Time for the drawdown angle calculation", [len(timeset)-1] + ["%.2f" % ts.second for ts in timeset]),
           ]

result = app.AskInput(asklist, 'Repose and drawdown angles calculation', 'Set inputs for angles calculation')

if(result[0] and result[2]):
    counter = 221
else:
    counter = 121
    #plt.figure(1, figsize=None)


def get_counter():
    global counter
    counter += 1
    return counter-1


#===================================================================================================
# close all user windows
#===================================================================================================
user_window_subject = app.GetUserWindowSubjects()
if user_window_subject:
    for mpl_window in list(user_window_subject):
        mpl_window.CloseWindow()
        

class ReposeAngle(object):
    
    def __init__(self):
    
        #time to calculate the repose angle
        #self.analysis_time_step = [len(timeset)/2][0]
        self.analysis_time_step = int(float(result[1]))                           
        
        #angle to create the cylinder slice
        self.cylinder_angle = 10
        
        #number of the particle size to calculate the bins size
        self.multiplier = (1.0)
    
    def go_to_time_step(self):
        #go to the time to calculate the repose angle
        app.GoToTimeStep(self.analysis_time_step)
        ProcessEvents()
        
    def define_cylinder_process(self):
        collection = project.GetUserProcessCollection()
        #get the particles equivalent diameters
        particles = study.GetParticles()
        diameters = particles.GetGridFunction('Particle Equivalent Diameter').GetArray()
        
        #get the limits of particles positions
        particles_limits_min = particles.GetBoundingBox()[0]
        particles_limits_max = particles.GetBoundingBox()[1]
        
        #get the dimension of the particles positions at each direction
        particles_x_size = (particles_limits_max[0] - particles_limits_min[0])
        particles_y_size = (particles_limits_max[1] - particles_limits_min[1])
        particles_z_size = (particles_limits_max[2] - particles_limits_min[2])
        
        #calculate the cylinder radius based on the particles distribution
        cylinder_radius = float(numpy.max([particles_x_size/2.0, particles_z_size/2.0]))
        cylinder_center = ((0),(particles_limits_min[1]+particles_y_size/2.0), (0))
        cylinder_height = particles_y_size

        #creating cylinder
        cylinder = collection.CreateCylinderProcess(particles)
        #orient cylinder
        cylinder.SetRotation(0,0,0)
        #center cylinder
        cylinder.SetCenter(cylinder_center[0], cylinder_center[1], cylinder_center[2])
        #set cylinder size
        cylinder.SetSize(float(2*cylinder_radius), float(cylinder_height), float(2*cylinder_radius))
        #setting cylinder hole ratio %
        cylinder.SetInternalFactor(0)
        #set initial angle
        cylinder.SetInitialAngle(0)
        #set final angle
        cylinder.SetFinalAngle(0+self.cylinder_angle)
        
        eul = collection.CreateEulerianStatistics(cylinder)
        
        #setting number of divisions
        self.radial_divisions = int(cylinder_radius/(self.multiplier*numpy.max(diameters)))
        
        eul.SetDivisions((self.radial_divisions,1,1))
        
        eul.CreateGridFunction('Max', 'Particle Y-Coordinate')
        
    def get_cylinder_slice_heights_and_radius(self, cylinder_index):
        
        #get the cylinder 
        collection = project.GetUserProcessCollection()
        cylinder_name = collection.GetCylinderProcessNames()[-1]
        cylinder = collection.GetProcess(cylinder_name)
        #set initial angle
        cylinder.SetInitialAngle(cylinder_index*self.cylinder_angle)
        #set final angle
        cylinder.SetFinalAngle(cylinder_index*self.cylinder_angle+self.cylinder_angle)
        #update cylinder
        ProcessEvents()
        
        #updating Eulerian process
        eul_name = collection.GetEulerianStatisticsNames()[-1]
        eul = collection.GetProcess(eul_name)
        #grid_function_name = eul.GetGridFunctionNames()[0]
        grid_function_name = 'Max of Particle Y-Coordinate'
        
        
        #get the maximum height 
        height = eul.GetGridFunction(grid_function_name).GetArray()
        #get the bin center
        bins_center = eul.GetCellCenterAsArray()
        n_bins_center = bins_center[0][0]
        #getting bins position (x, y, z)
        bins_x = n_bins_center[:,0]
        bins_z = n_bins_center[:,2]
        # getting bins radius
        bins_radius = numpy.sqrt((bins_x*bins_x+bins_z*bins_z))
        return (bins_radius, height)

    def get_cylinder_slice_repose_angle(self, cylinder_index, bin_radius, height):
        #get the maximum value of the cylinder        
        max_value_height_cylinder_index = numpy.argmax(height, axis=None)

        #new arrays excluding the points left from the maximum value of height
        new_height_array = height[max_value_height_cylinder_index+1::]
        new_radius_array = bin_radius[max_value_height_cylinder_index+1::]
        
        zero_values = numpy.where(new_height_array==0)
        print(zero_values[0])
        
        if (len(zero_values[0]) > 0):
            height_without_zeros = new_height_array[0:zero_values[0][0]]
            radius_without_zeros = new_radius_array[0:zero_values[0][0]]
        else:
            height_without_zeros = new_height_array
            radius_without_zeros = new_radius_array
                
        array_lenght = len(height_without_zeros)
        
        initial_number_of_points = numpy.maximum(2,int(array_lenght/2.0))
        
        
        x_array_to_adjust = radius_without_zeros[int(array_lenght/2-initial_number_of_points/2):int(array_lenght/2+initial_number_of_points/2)]
        y_array_to_adjust = height_without_zeros[int(array_lenght/2-initial_number_of_points/2):int(array_lenght/2+initial_number_of_points/2)]
        adjusted_line = numpy.polyfit(x_array_to_adjust, y_array_to_adjust, 1)
        tangent = adjusted_line[0]
        
        #calculating angle
        angle = math.degrees(math.atan(math.fabs(tangent)))
        tolerance_for_point_inclusion = 10.0
        
        last_point_ok = int(array_lenght/2+initial_number_of_points/2)
        
        #loop for the right 
        total_repose_points = initial_number_of_points
        for point in numpy.arange(int(array_lenght/2+initial_number_of_points/2),array_lenght):
            #adjusting th eline to get the angle
            y_difference = height_without_zeros[last_point_ok-1]-height_without_zeros[point]
            x_difference = radius_without_zeros[point]-radius_without_zeros[last_point_ok-1]
            tangent_local = y_difference/x_difference
            angle_local = math.degrees(math.atan(math.fabs(tangent_local)))
            diff = math.fabs(angle - angle_local)
            total_repose_points = total_repose_points + 1
                        
            if (diff < tolerance_for_point_inclusion):
                last_point_ok = point
                x_array_to_adjust = numpy.append(x_array_to_adjust, radius_without_zeros[point])
                y_array_to_adjust = numpy.append(y_array_to_adjust, height_without_zeros[point])
                
                adjusted_line = numpy.polyfit(x_array_to_adjust, y_array_to_adjust, 1)
                tangent = adjusted_line[0]

                #calculating angle
                angle = math.degrees(math.atan(math.fabs(tangent)))
                        
        last_point_ok = int(array_lenght/2-initial_number_of_points/2)
        
        #loop for the left
        for point in numpy.arange(array_lenght/2-initial_number_of_points/2,0,-1):
            #adjusting th eline to get the angle
            point=int(point)
            y_difference = height_without_zeros[point]-height_without_zeros[last_point_ok+1]
            x_difference = radius_without_zeros[last_point_ok+1]-radius_without_zeros[point]
            tangent_local = y_difference/x_difference
            angle_local = math.degrees(math.atan(math.fabs(tangent_local)))
            diff = math.fabs(angle - angle_local)
            total_repose_points = total_repose_points + 1
                        
            if (diff < tolerance_for_point_inclusion):
                last_point_ok = point
                x_array_to_adjust = numpy.append(x_array_to_adjust, radius_without_zeros[point])
                y_array_to_adjust = numpy.append(y_array_to_adjust, height_without_zeros[point])
                
                adjusted_line = numpy.polyfit(x_array_to_adjust, y_array_to_adjust, 1)
                tangent = adjusted_line[0]
                #calculating angle
                angle = math.degrees(math.atan(math.fabs(tangent)))
        print("total repose points = ", total_repose_points )
        return(angle, adjusted_line[0], adjusted_line[1], x_array_to_adjust, y_array_to_adjust)
    
    def get_average_repose_angle_radius_and_height(self):
        
        number_of_cylinders = int(360/self.cylinder_angle)
        average_radius = numpy.zeros((self.radial_divisions), numpy.float64)
        average_height = numpy.zeros((self.radial_divisions), numpy.float64)        
        repose_angles = numpy.zeros((number_of_cylinders), numpy.float64)

        average_adjusted_line_a = 0.0
        average_adjusted_line_b = 0.0
        
        
        for cylinder_index in range(number_of_cylinders):
                bins_radius, height = self.get_cylinder_slice_heights_and_radius(cylinder_index)
                angle, line_a, line_b, _, _ = self.get_cylinder_slice_repose_angle(cylinder_index, bins_radius, height)
                
                average_radius += bins_radius
                average_height += height

                average_adjusted_line_a += line_a
                average_adjusted_line_b += line_b
                repose_angles[cylinder_index] = angle

        # calculate final averages
        average_radius /= float(number_of_cylinders)
        average_height /= float(number_of_cylinders)
        average_adjusted_line_a /= float(number_of_cylinders)
        average_adjusted_line_b /= float(number_of_cylinders)
        #average_repose_angle /= float(self.number_of_cylinders)
        
#        def reject_outliers(data, m = 2.):
#            d = numpy.abs(data - numpy.median(data))
#            mdev = numpy.median(d)
#            s = d/mdev if mdev else 0.
#            return data[s<m]
        def reject_outliers(data, m):
            return data[abs(data - numpy.mean(data)) < m * numpy.std(data)]
            
        repose_angles_without_outliers = reject_outliers(repose_angles, 2.)
        repose_angle_average = numpy.average(repose_angles_without_outliers)
        repose_angle_standard_deviation = numpy.std(repose_angles_without_outliers)
       
        return(repose_angles_without_outliers, repose_angles, repose_angle_average, repose_angle_standard_deviation, average_radius, average_height, average_adjusted_line_a, average_adjusted_line_b )
        
    def plot_repose_angle(self, repose_values):

        repose_angles_without_outliers, repose_angles, repose_angle_average, repose_angle_standard_deviation, average_radius, average_height, average_adjusted_line_a, average_adjusted_line_b  = repose_values
        max_value_height_cylinder_index = numpy.argmax(average_height, axis=None)
        #plotting results
        p = numpy.poly1d([average_adjusted_line_a, average_adjusted_line_b])
        xp = numpy.linspace(average_radius[max_value_height_cylinder_index], average_radius[-1], 100)
        

        plt.subplot(get_counter())
        plt.plot(xp, p(xp), '-', color = "red")
        plt.plot(average_radius, average_height,linestyle = 'None', marker = 'D', color = 'green')    
        plt.title("Repose angle calculation", fontsize = 15 )
        plt.xlim([average_radius[0],average_radius[-1]])
        plt.ylim([0,average_adjusted_line_b])
        plt.xlabel('Radius [m] ', fontsize = 15)
        plt.ylabel('Height [m] ', fontsize = 15)
        plt.text(average_radius[-1]/4,  average_adjusted_line_b/3, r'$\theta$ = '+ "{:0.4f}".format(repose_angle_average) + u"\u00b0" + "\n $\sigma$ = "+ "{:0.4f}".format(repose_angle_standard_deviation) + u"\u00b0" , fontsize=15, color = "red")


        plt.subplot(get_counter())
        x_array2 = numpy.arange(len(repose_angles_without_outliers))+1
        y_array2 = repose_angles_without_outliers
        plt.errorbar(x_array2, y_array2, yerr=repose_angle_standard_deviation, linestyle = 'None', marker = 'o', color = 'green')        
        plt.axhline(y = repose_angle_average)        
        plt.title("Repose angle calculation", fontsize = 15 )
        plt.ylim([0,90])
        plt.xlabel('Slice number ', fontsize = 15)
        plt.ylabel(u'Repose angle \u00b0 ', fontsize = 15)

        
    def include_repose_angle_as_output_parameter(self, repose_values):
        
        particles = study.GetParticles()
        
        current_time_step = app.GetCurrentTimeStep()
        
        repose_angle_average = repose_values[2]
        
        particles.AddCurve('Repose angle', [current_time_step],[repose_angle_average], 'dega')
        
        scripting = app._GetScripting()
        my_curve_assoc = particles.GetCurveNamesAssociation()['Repose angle (User)']
        scripting.AddCurveOutputVariable('Repose angle', my_curve_assoc, 'max', particles.id)
        
    def repose_angle_calculation(self):
        
        self.go_to_time_step()

        self.define_cylinder_process()
        
        repose_values = self.get_average_repose_angle_radius_and_height()
        
        self.plot_repose_angle(repose_values)
        
        self.include_repose_angle_as_output_parameter(repose_values)
        



class DrawdownAngle:
    
    def __init__(self):
        
        #self.analysis_time_step = [len(timeset)-1][0]
        self.analysis_time_step = int(float(result[3]))  
        self.height_multiplier = 2.0
        self.multiplier = (1.0)
 
    
    def go_to_time_step(self):
        app.GoToTimeStep(self.analysis_time_step)
        ProcessEvents()
         
    def define_cube_process(self):
        collection = project.GetUserProcessCollection()
        #get the particles equivalent diameters
        particles = study.GetParticles()
        diameters = particles.GetGridFunction('Particle Equivalent Diameter').GetArray()
        max_equivalent_diameter = numpy.max(diameters)

        particles_limits_min = particles.GetBoundingBox()[0]
        particles_limits_max = particles.GetBoundingBox()[1]

        particles_x_size = (particles_limits_max[0] - particles_limits_min[0])
        particles_y_size = (particles_limits_max[1] - particles_limits_min[1])
       
        self.cube_lenght = numpy.max([particles_x_size/2.0])
        self.cube_center = ((particles_limits_min[0]+particles_x_size/2.0),(particles_limits_min[1]+particles_y_size/2.0), (0))
        self.cube_height = particles_y_size
        self.cube_width = self.height_multiplier*self.cube_height
        
        self.number_of_cubes = int(self.cube_width/(self.multiplier*max_equivalent_diameter))
        self.cube_divisions = int(self.cube_lenght/(self.multiplier*max_equivalent_diameter))
        
        #creating cube
        cube = collection.CreateCubeProcess(particles)
        
        #cube size
        self.bin_size = (self.cube_width/self.number_of_cubes)
        #orient cube
        cube.SetCubeRotation(0,0,0)
        #set cube size
        cube.SetSize(float(self.cube_lenght), float(self.cube_height), float(self.bin_size))
        #center cube
        cube.SetCenter(self.cube_center[0]+self.cube_lenght/2, self.cube_center[1], self.cube_center[2])
        
        eul = collection.CreateEulerianStatistics(cube)
        #setting number of divisions
        eul.SetDivisions((self.cube_divisions,1,1))
        #creating max particle height function
        eul.CreateGridFunction('Max', 'Particle Y-Coordinate') 
        
        
        
    def get_cube_slice_heights_and_radius(self, cube_index):
        
              
        collection = project.GetUserProcessCollection()
        
        cube_name = collection.GetCubeProcessNames()[-1]
        
        cube = collection.GetProcess(cube_name)
            
        #set cube center
        cube.SetCenter(self.cube_center[0]+self.cube_lenght/2, self.cube_center[1], (self.cube_center[2]-self.cube_width/2)+(cube_index*self.bin_size))

        ProcessEvents()
            
        eul_name = collection.GetEulerianStatisticsNames()[-1]
        
        eul = collection.GetProcess(eul_name)
        
        grid_function_name = 'Max of Particle Y-Coordinate'
    
        height = eul.GetGridFunction(grid_function_name).GetArray()

        bins_center = eul.GetCellCenterAsArray()
        n_bins_center = bins_center[0][0]
        #getting bins position (x, y, z)
        bins_x = n_bins_center[:,0]
                    
        bins_position = bins_x
        return (bins_position, height)
    
    def get_cube_slice_drawdown_angle(self, cube_index):
        bins_position, height = self.get_cube_slice_heights_and_radius(cube_index)
                
        zero_values = numpy.where(height==0)
        non_zero_values = numpy.where(height!=0)
                
        if (len(zero_values[0]) > 0):
            height_without_left_zeros = height[non_zero_values[0][0]:]
            position_without_left_zeros = bins_position[non_zero_values[0][0]:]
        else:
            height_without_left_zeros = height
            position_without_left_zeros = bins_position
            
        new_zero_values = numpy.where(height_without_left_zeros==0)
        if (len(new_zero_values[0]) > 0):
            height_without_zeros = height_without_left_zeros[0:new_zero_values[0][0]]
            position_without_zeros = position_without_left_zeros[0:new_zero_values[0][0]]
        else:
            height_without_zeros = height_without_left_zeros
            position_without_zeros = position_without_left_zeros
        
        #print(new_height_array)
        max_value_index = numpy.argmax(height_without_zeros, axis=None)

        new_height_array3 = height_without_zeros[0:max_value_index+1]
        new_position_array3 = position_without_zeros[0:max_value_index+1]
                
        initial_number_of_points = int(numpy.maximum(2,len(new_position_array3)/2 ))
        
        x_array_to_adjust = new_position_array3[0:initial_number_of_points]
        y_array_to_adjust = new_height_array3[0:initial_number_of_points]
        
        adjusted_line = numpy.polyfit(x_array_to_adjust, y_array_to_adjust, 1)
        tangent = adjusted_line[0]

        #calculating angle
        angle = math.degrees(math.atan(math.fabs(tangent)))
        
        tolerance_for_point_inclusion = 15.0
        
        last_point_ok = initial_number_of_points-1
        total_drawdown_points = initial_number_of_points
        for point in numpy.arange(initial_number_of_points,len(new_height_array3)):
            #adjusting the line to get the angle
            y_difference = new_height_array3[point]-new_height_array3[last_point_ok-1]
            x_difference = new_position_array3[point]-new_position_array3[last_point_ok-1]
            tangent_local = y_difference/x_difference
            angle_local = math.degrees(math.atan(math.fabs(tangent_local)))
            
            diff = math.fabs(angle - angle_local)
            
            if (diff < tolerance_for_point_inclusion):
                last_point_ok = point
                x_array_to_adjust = numpy.append(x_array_to_adjust, new_position_array3[point])
                y_array_to_adjust = numpy.append(y_array_to_adjust, new_height_array3[point])
                total_drawdown_points = total_drawdown_points + 1
                adjusted_line = numpy.polyfit(x_array_to_adjust, y_array_to_adjust, 1)
                tangent = adjusted_line[0]
                #calculating angle
                angle = math.degrees(math.atan(math.fabs(tangent)))    
        print("total_drawdown_points = ", total_drawdown_points)       
        return(angle, adjusted_line[0], adjusted_line[1])

    def get_average_drawdown_angle_position_and_height(self):
        
        average_position = numpy.zeros((self.cube_divisions), numpy.float64)
        average_height = numpy.zeros((self.cube_divisions), numpy.float64)        
        drawdown_angles = numpy.zeros((self.number_of_cubes), numpy.float64)

        average_adjusted_line_a = 0.0
        average_adjusted_line_b = 0.0
        
        
        for cube_index in range(self.number_of_cubes):
            bin_position, height = self.get_cube_slice_heights_and_radius(cube_index)
            angle, line_a, line_b = self.get_cube_slice_drawdown_angle(cube_index)     
            #line_a = self.get_cube_slice_drawdown_angle(cube_index)[1]
            #line_b = self.get_cube_slice_drawdown_angle(cube_index)[2]
                
            average_position += bin_position
            average_height += height

            average_adjusted_line_a += line_a
            average_adjusted_line_b += line_b
            drawdown_angles[cube_index] = angle

        # calculate final averages
        average_position /= float(self.number_of_cubes)

        average_height /= float(self.number_of_cubes)
        average_adjusted_line_a /= float(self.number_of_cubes)
        average_adjusted_line_b /= float(self.number_of_cubes)
        
#        def reject_outliers(data, m = 2.):
#            d = numpy.abs(data - numpy.median(data))
#            mdev = numpy.median(d)
#            s = d/mdev if mdev else 0.
#            return data[s<m]
        def reject_outliers(data, m):
            return data[abs(data - numpy.mean(data)) < m * numpy.std(data)]
            
        drawdown_angles_without_outliers = reject_outliers(drawdown_angles, 3)
        drawdown_angle_average = numpy.average(drawdown_angles_without_outliers)
        drawdown_standard_deviation = numpy.std(drawdown_angles_without_outliers)

        
        return(drawdown_angles_without_outliers, drawdown_angles, drawdown_angle_average, drawdown_standard_deviation, average_position, average_height, average_adjusted_line_a, average_adjusted_line_b )
        
    
    def plot_drawdown_angle(self, drawdown_values):
        
        drawdown_angles_without_outliers, drawdown_angles, drawdown_angle_average, drawdown_standard_deviation, average_position, average_height, average_adjusted_line_a, average_adjusted_line_b   = drawdown_values

        #plotting results
        p = numpy.poly1d([average_adjusted_line_a, average_adjusted_line_b])
        xp = numpy.linspace(average_position[0], average_position[-1], 100)
        
        plt.subplot(get_counter())
        plt.plot(xp, p(xp), '-', color = "red")
        plt.plot(average_position, average_height, linestyle = 'None', marker = 'D', color = 'green')
         
        plt.title("Drawdown angle calculation", fontsize = 15 )
        plt.xlim([average_position[0],average_position[-1]])
        plt.ylim([0,1.2*numpy.amax(average_height)])
        plt.xlabel('Position [m] ', fontsize = 15)
        plt.ylabel('Height [m] ', fontsize = 15)
        plt.text(average_position[-1]/3,  numpy.amax(average_height)/3, r'$\theta$ = '+ "{:0.4f}".format(drawdown_angle_average) + u"\u00b0" + "\n $\sigma$ = "+ "{:0.4f}".format(drawdown_standard_deviation) + u"\u00b0" , fontsize=15, color = "red")

        #plt.show()
        
        plt.subplot(get_counter())
        x_array = numpy.arange(len(drawdown_angles))+1
        x_array2 = numpy.arange(len(drawdown_angles_without_outliers))+1
        y_array = drawdown_angles
        y_array2 = drawdown_angles_without_outliers
        plt.errorbar(x_array2, y_array2, yerr=drawdown_standard_deviation, linestyle = 'None', marker = 'o', color = 'blue')        
        plt.axhline(y = drawdown_angle_average)        
        plt.title("Drawdown angle calculation", fontsize = 15 )
        plt.ylim([0,90])
        plt.xlabel('Slice number ', fontsize = 15)
        plt.ylabel(u'Drawdown angle \u00b0 ', fontsize = 15)

        
    def include_drawdown_angle_as_output_parameter(self, drawdown_values):
        
        particles = study.GetParticles()
        
        current_time_step = app.GetCurrentTimeStep()
        
        drawdown_angle_average = drawdown_values[2]
        
        drawdown_angle_curve = particles.AddCurve('Drawdown angle', [current_time_step],[drawdown_angle_average], 'dega')
        scripting = app._GetScripting()
        my_curve_assoc = particles.GetCurveNamesAssociation()['Drawdown angle (User)']
        scripting.AddCurveOutputVariable('Drawdown angle', my_curve_assoc, 'max', particles.id)
        
        #print("number of cubes = ", self.number_of_cubes)

    def drawdown_angle_calculation(self):
        
        self.go_to_time_step()
        
        self.define_cube_process()
        
        drawdown_values = self.get_average_drawdown_angle_position_and_height()
        
        self.plot_drawdown_angle(drawdown_values)
        
        self.include_drawdown_angle_as_output_parameter(drawdown_values)


plt.close("all")

if(result[0] and result[2]):
    plt.figure(1, figsize=(14, 11))
else:
    plt.figure(1, figsize=(14, 5))
    #plt.figure(1, figsize=None)

plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=0.2, hspace=0.3)

if(result[0]):
    repose_angle = ReposeAngle()
    repose_angle.repose_angle_calculation()

if(result[2]):
    drawdown_angle = DrawdownAngle()
    drawdown_angle.drawdown_angle_calculation()

plt.show()


